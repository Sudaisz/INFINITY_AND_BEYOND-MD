<h1 align="center"> INFINITY AND BEYOND V1.4.0</h1>
<p align="center">  
  
***
  
<a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=Black+Ops+One&size=50&pause=1000&color=1BAFBAFF&center=true&width=910&height=100&lines=THANKS FOR CHOOSING ;RIAS_GREMORY-BOT;MULTI+DEVICE+WHATSAPP+BOT;CREATED+BY+TOXXIC+BOY;RELEASED+09.07.24" alt="Typing SVG" /></a>
  </p>
    <img alt="INFINITY" width="960" height="720" src="https://tinyurl.com/ry4d6j4d">
<p align="center">
<priasgremorybot align="center">
<a href="https://github.com/Sudaisz/INFINITY_AND_BEYOND-MD.git"><img title="Author" src="https://img.shields.io/badge/Rias Gremory-black?style=for-the-badge&logo=github"></a>
<p align="center">
<a href="https://github.com/Toxic1239/followers"><img title="Followers" src="https://img.shields.io/github/followers/Toxic1239?color=blue&style=flat-square"></a>
<a href="https://github.com/Toxic1239/RIASGREMORYBOT/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/Toxic1239/RIASGREMORYBOT?color=red&style=flat-square"></a>
<a href="https://github.com/Toxic1239/RIASGREMORYBOT/network/members"><img title="Forks" src="https://img.shields.io/github/forks/Toxic1239/RIASGREMORYBOT?color=green&style=flat-square"></a>
<a href="https://github.com/Sudaisz/INFINITY_AND_BEYOND-MD.git/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/github.com/Sudaisz/INFINITY_AND_BEYOND-MD.git?label=Watchers&color=yellow&style=flat-square"></a>

#### SETUP 
### IF YOU WANNA DEPLOY USING CREDS.JSON ADD THE CREDS TO LIB/SESSIONS FOLDER 

### 1.`First STAR 🌟 This Repo ` And Then [`FORK`](https://github.com/Sudaisz/INFINITY_AND_BEYOND-MD.git/fork) It

### 2. GET SESSION ID HERE 

<a href='https://malvin-session-fzow.onrender.com/' target="_blank"><img alt='PAIR CODE' src='https://img.shields.io/badge/Click here to get your session id-blue?style=for-the-badge&logo=opencv&logoColor=white'/></a> 
### 3. GET CREDS.JSON HERE 

none

### STEP 2
ADD SESSION ID TO YOUR FORKED REPO IN CONFIG.JS
AND DEPLOY

### DEPLOY ON SCALINGO

1. If you don't have an account in Scalingo, create one and deploy.
    <br>
    <a href='https://auth.scalingo.com/users/sign_in' target="_blank"><img alt='REPLIT' src='https://img.shields.io/badge/-DEPLOY-orange?style=for-the-badge&logo=scalingo&logoColor=white'/></a>


### DEPLOY ON REPLIT
IF YOU DON'T HAVE A REPLIT ACCOUNT CREATE ONE AND DEPLOY 
    <br>
    <a href='https://replit.com/github.com/Sudaisz/INFINITY_AND_BEYOND-MD.git' target="_blank"><img alt='Replit' src='https://img.shields.io/badge/-Deploy-red?style=for-the-badge&logo=replit&logoColor=white'/></a>
    
 ### DEPLOY ON RAILWAY 
1. Deploy.
    <br>
    <a href='https://railway.com/github.com/Sudaisz/INFINITY_AND_BEYOND-MD.git' target="_blank"><img alt='Railway' src='https://img.shields.io/badge/-Deploy-green?style=for-the-badge&logo=render&logoColor=white'/></a>

 ### DEPLOY ON RENDER 
1. NOT AVAILABLE 
    
### DEPLOY ON CODESPACE 
1. Deploy. `Free`
Add session Id to config.js and then deploy to codespace
    <br>
    <a href='https://github.com/codespaces' target="_blank"><img alt='Codespace' src='https://img.shields.io/badge/-Deploy-green?style=for-the-badge&logo=codespace&logoColor=white'/></a>

***


### CONTRIBUTIONS 
-Contributions to INFINITY_AND_BWYOND-BOT are welcome! If you have ideas for new features, improvements, or bug fixes, feel free to open an issue or submit a pull request.

<br>
    <a href='https://github.com/Sudaisz/INFINITY_AND_BEYOND-MD.git/issues/new/choose' target="_blank"><img alt='Railway' src='https://img.shields.io/badge/-REPORT ISSUE-red?style=for-the-badge&logo=railway&logoColor=white'/></a>


***

### LICENSE 
-The RIAS_GREMORY-BOT is released under the [MIT License](https://opensource.org/licenses/MIT).

-Enjoy the diverse features of the RIAS_GREMORY-BOT  to enhance your conversations and make your WhatsApp experience more interesting!

***
### DEVELOPER:
**GET In Touch with The Owner**
- [**On TELEGRAM**](COMING-SOON)

***
### WARNING

- **INFINITY-BOT is not made by `WhatsApp Inc.` Sometimes or misusing the bot might `ban` your `WhatsApp account!`*
- *In that case, I'm not responsible for banning your account.*
- *Use RIAS-GREMORY at your own risk by keeping this warning in mind.*
  
  #### ```TOTAL REPO VIEWS 🧚```
![Visitor Count](https://profile-counter.glitch.me/Sudaisz/count.svg)

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

 ## [ WHATSAPP CHANNEL ](https://whatsapp.com/channel/0029Vaoi15YAojYuT1dU8q2H) 

### THANKS TO:

- WASI FOR SESSION ID METHOD
- ASTRO FOR THE BASE I USED
- KING FOR SONG DOWNLOADER FIX 
